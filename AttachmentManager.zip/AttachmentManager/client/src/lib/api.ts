import { apiRequest } from "./queryClient";
import type { InsertTeam, InsertOrder } from "@shared/schema";

export const api = {
  // Team operations
  createTeam: async (team: InsertTeam) => {
    const response = await apiRequest("POST", "/api/teams", team);
    return response.json();
  },

  getTeams: async () => {
    const response = await apiRequest("GET", "/api/teams");
    return response.json();
  },

  // Merchandise operations
  getMerchandise: async () => {
    const response = await apiRequest("GET", "/api/merchandise");
    return response.json();
  },

  getMerchandiseItem: async (id: number) => {
    const response = await apiRequest("GET", `/api/merchandise/${id}`);
    return response.json();
  },

  // Order operations
  createOrder: async (order: InsertOrder) => {
    const response = await apiRequest("POST", "/api/orders", order);
    return response.json();
  },

  getOrders: async () => {
    const response = await apiRequest("GET", "/api/orders");
    return response.json();
  },
};
