import Navbar from "@/components/navbar";
import Hero from "@/components/hero";
import EventInfo from "@/components/event-info";
import Prizes from "@/components/prizes";
import Merchandise from "@/components/merchandise";
import Activities from "@/components/activities";
import Registration from "@/components/registration";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <EventInfo />
      <Prizes />
      <Merchandise />
      <Activities />
      <Registration />
      <Footer />
    </div>
  );
}
