import { useState, useCallback } from "react";
import type { MerchandiseItem } from "@shared/schema";

export interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  selectedColor?: string;
}

export function useCart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const addToCart = useCallback((item: MerchandiseItem, selectedColor?: string) => {
    setCartItems(prev => {
      const existingItem = prev.find(cartItem => 
        cartItem.id === item.id && cartItem.selectedColor === selectedColor
      );

      if (existingItem) {
        return prev.map(cartItem =>
          cartItem.id === item.id && cartItem.selectedColor === selectedColor
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }

      return [...prev, {
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1,
        selectedColor,
      }];
    });
  }, []);

  const removeFromCart = useCallback((id: number, selectedColor?: string) => {
    setCartItems(prev => 
      prev.filter(item => !(item.id === id && item.selectedColor === selectedColor))
    );
  }, []);

  const updateQuantity = useCallback((id: number, quantity: number, selectedColor?: string) => {
    if (quantity <= 0) {
      removeFromCart(id, selectedColor);
      return;
    }

    setCartItems(prev =>
      prev.map(item =>
        item.id === id && item.selectedColor === selectedColor
          ? { ...item, quantity }
          : item
      )
    );
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  const cartTotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const cartItemCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  return {
    cartItems,
    cartTotal,
    cartItemCount,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
  };
}
