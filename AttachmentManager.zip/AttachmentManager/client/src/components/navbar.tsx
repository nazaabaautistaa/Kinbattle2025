import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/90 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-2xl font-gaming font-bold gradient-text">KINBATTLE</div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection("evento")}
                className="hover:text-neon-pink transition-colors duration-300"
              >
                Evento
              </button>
              <button 
                onClick={() => scrollToSection("premios")}
                className="hover:text-neon-pink transition-colors duration-300"
              >
                Premios
              </button>
              <button 
                onClick={() => scrollToSection("merch")}
                className="hover:text-neon-pink transition-colors duration-300"
              >
                Merchandise
              </button>
              <Button 
                onClick={() => scrollToSection("inscripcion")}
                className="bg-gradient-to-r from-neon-pink to-neon-blue hover:shadow-lg hover:shadow-neon-pink/50 transition-all duration-300"
              >
                ¡Inscríbete!
              </Button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white hover:text-neon-pink"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-card border-t border-border">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <button 
              onClick={() => scrollToSection("evento")}
              className="block px-3 py-2 w-full text-left hover:text-neon-pink transition-colors"
            >
              Evento
            </button>
            <button 
              onClick={() => scrollToSection("premios")}
              className="block px-3 py-2 w-full text-left hover:text-neon-pink transition-colors"
            >
              Premios
            </button>
            <button 
              onClick={() => scrollToSection("merch")}
              className="block px-3 py-2 w-full text-left hover:text-neon-pink transition-colors"
            >
              Merchandise
            </button>
            <button 
              onClick={() => scrollToSection("inscripcion")}
              className="block px-3 py-2 w-full text-left text-neon-pink font-semibold"
            >
              ¡Inscríbete!
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
