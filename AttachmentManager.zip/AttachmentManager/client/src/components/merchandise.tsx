import { useQuery } from "@tanstack/react-query";
import { Store, Star, Leaf, Flame, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import type { MerchandiseItem } from "@shared/schema";

export default function Merchandise() {
  const { toast } = useToast();
  const { addToCart, cartItems, cartTotal } = useCart();

  const { data: merchandise, isLoading } = useQuery<MerchandiseItem[]>({
    queryKey: ["/api/merchandise"],
  });

  const handleAddToCart = (item: MerchandiseItem) => {
    addToCart(item);
    toast({
      title: "¡Añadido al carrito!",
      description: `${item.name} ha sido añadido a tu carrito.`,
    });
  };

  const getItemIcon = (iconClass: string) => {
    // Map icon classes to actual icons
    const iconMap: { [key: string]: React.ReactNode } = {
      "fas fa-tshirt": "👕",
      "fas fa-hat-cowboy": "🧢", 
      "fas fa-bottle-water": "🥤",
      "fas fa-hand": "🤝",
    };
    return iconMap[iconClass] || "🎁";
  };

  const getBadge = (name: string) => {
    if (name.includes("Gorra")) return <Star className="h-4 w-4 text-yellow-400" />;
    if (name.includes("Botella")) return <Leaf className="h-4 w-4 text-green-400" />;
    if (name.includes("Pulseras")) return <Flame className="h-4 w-4 text-orange-400" />;
    return null;
  };

  if (isLoading) {
    return (
      <section id="merch" className="py-20 bg-gradient-to-b from-card to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-neon-pink mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Cargando merchandise...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="merch" className="py-20 bg-gradient-to-b from-card to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-gaming font-bold gradient-text mb-4">
            <Store className="inline mr-4" />
            Merchandise Oficial
          </h2>
          <p className="text-xl text-muted-foreground">
            Lleva contigo el espíritu de KINBATTLE
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {merchandise?.map((item) => (
            <Card key={item.id} className="neon-border bg-card hover:neon-glow transition-all duration-300 group overflow-hidden">
              <div className="h-48 bg-gradient-to-br from-neon-pink/20 to-neon-blue/20 flex items-center justify-center">
                <div className="text-6xl">{getItemIcon(item.icon)}</div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2 text-neon-pink">{item.name}</h3>
                <p className="text-muted-foreground mb-4">{item.description}</p>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-2xl font-bold text-white">{(item.price / 100).toFixed(2)}€</span>
                  <div className="flex items-center space-x-2">
                    {getBadge(item.name)}
                    {item.colors && (
                      <div className="flex space-x-1">
                        {item.colors.map((color, index) => (
                          <div 
                            key={index}
                            className="w-4 h-4 rounded-full border border-gray-600"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <Button 
                  onClick={() => handleAddToCart(item)}
                  className="w-full bg-gradient-to-r from-neon-pink to-neon-blue hover:shadow-lg transition-all duration-300"
                >
                  Añadir al carrito
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Cart Summary */}
        {cartItems.length > 0 && (
          <div className="mt-12 text-center">
            <div className="inline-flex items-center space-x-4 bg-card rounded-full px-6 py-3 neon-border">
              <ShoppingCart className="h-5 w-5 text-neon-pink" />
              <span>{cartItems.length}</span>
              <span className="text-muted-foreground">artículos en el carrito</span>
              <span className="text-2xl font-bold text-white">€{(cartTotal / 100).toFixed(2)}</span>
              <Button 
                variant="outline"
                className="bg-neon-pink border-neon-pink hover:shadow-lg transition-all duration-300"
              >
                Ver carrito
              </Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
