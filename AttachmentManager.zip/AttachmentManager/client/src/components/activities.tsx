import { Gamepad, Trophy, Star, Music } from "lucide-react";

export default function Activities() {
  const activities = [
    {
      icon: Trophy,
      title: "Torneo por Equipos",
      description: "Competición oficial de Kin-ball con equipos de tres jugadores. Sistema de eliminación directa para máxima emoción.",
      color: "from-neon-pink/20",
      iconColor: "text-neon-pink",
    },
    {
      icon: Star,
      title: "Exhibición Profesional",
      description: "Demostración de técnicas avanzadas por parte de jugadores profesionales. Aprende los mejores movimientos.",
      color: "from-neon-blue/20",
      iconColor: "text-neon-blue",
    },
    {
      icon: Music,
      title: "Zona de Animación",
      description: "DJ en vivo con música energética durante todo el evento. Ambiente festivo garantizado para todos los participantes.",
      color: "from-purple-500/20",
      iconColor: "text-purple-400",
    },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-gaming font-bold gradient-text mb-4">
            <Gamepad className="inline mr-4" />
            Actividades
          </h2>
          <p className="text-xl text-muted-foreground">
            Una experiencia completa de entretenimiento
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {activities.map((activity, index) => (
            <div key={index} className="text-center group">
              <div className={`bg-gradient-to-br ${activity.color} to-transparent rounded-full w-32 h-32 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                <activity.icon className={`h-12 w-12 ${activity.iconColor}`} />
              </div>
              <h3 className={`text-2xl font-bold mb-4 ${activity.iconColor}`}>{activity.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {activity.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
