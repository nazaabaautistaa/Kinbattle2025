import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { UserPlus, Users, Mail, Phone, MessageSquare, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTeamSchema, type InsertTeam } from "@shared/schema";
import { z } from "zod";

const formSchema = insertTeamSchema.extend({
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "Debes aceptar los términos y condiciones",
  }),
});

type FormData = z.infer<typeof formSchema>;

export default function Registration() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      category: "",
      members: ["", "", ""],
      contactEmail: "",
      contactPhone: "",
      additionalInfo: "",
      termsAccepted: false,
    },
  });

  const registerTeam = useMutation({
    mutationFn: async (data: InsertTeam) => {
      const response = await apiRequest("POST", "/api/teams", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "¡Registro exitoso!",
        description: "Tu equipo ha sido registrado correctamente. Te contactaremos pronto.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error en el registro",
        description: error.message || "No se pudo registrar el equipo. Inténtalo de nuevo.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    const { termsAccepted, ...teamData } = data;
    registerTeam.mutate(teamData);
  };

  return (
    <section id="inscripcion" className="py-20 bg-gradient-to-br from-card via-background to-card">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-gaming font-bold gradient-text mb-4">
            <UserPlus className="inline mr-4" />
            Inscripción
          </h2>
          <p className="text-xl text-muted-foreground">
            ¡Únete a la batalla más épica del año!
          </p>
        </div>

        <div className="neon-border rounded-xl p-8 bg-card">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Team Name */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neon-pink flex items-center">
                        <Users className="mr-2 h-4 w-4" />
                        Nombre del Equipo
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Los Guerreros del Kinball"
                          className="bg-background border-border focus:border-neon-pink"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Category */}
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neon-blue flex items-center">
                        <Users className="mr-2 h-4 w-4" />
                        Categoría
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background border-border focus:border-neon-blue">
                            <SelectValue placeholder="Selecciona categoría" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="junior">Junior (12-16 años)</SelectItem>
                          <SelectItem value="senior">Senior (17+ años)</SelectItem>
                          <SelectItem value="mixto">Mixto</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Team Members */}
              <div>
                <FormLabel className="text-neon-pink flex items-center mb-4">
                  <Users className="mr-2 h-4 w-4" />
                  Miembros del Equipo (3 jugadores)
                </FormLabel>
                <div className="grid md:grid-cols-3 gap-4">
                  {[0, 1, 2].map((index) => (
                    <FormField
                      key={index}
                      control={form.control}
                      name={`members.${index}` as const}
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input 
                              placeholder={`Jugador ${index + 1}`}
                              className="bg-background border-border focus:border-neon-pink"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>

              {/* Contact Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="contactEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neon-blue flex items-center">
                        <Mail className="mr-2 h-4 w-4" />
                        Email de Contacto
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="equipo@email.com"
                          className="bg-background border-border focus:border-neon-blue"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neon-pink flex items-center">
                        <Phone className="mr-2 h-4 w-4" />
                        Teléfono
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="tel"
                          placeholder="+34 600 000 000"
                          className="bg-background border-border focus:border-neon-pink"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Additional Information */}
              <FormField
                control={form.control}
                name="additionalInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-muted-foreground flex items-center">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Información Adicional (Opcional)
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Experiencia previa, necesidades especiales, etc."
                        className="bg-background border-border focus:border-gray-400 resize-none"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Terms and Conditions */}
              <FormField
                control={form.control}
                name="termsAccepted"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="data-[state=checked]:bg-neon-pink data-[state=checked]:border-neon-pink"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm text-muted-foreground">
                        Acepto los{" "}
                        <button 
                          type="button" 
                          className="text-neon-pink hover:underline"
                          onClick={() => toast({ title: "Términos y condiciones", description: "Los términos y condiciones se mostrarían aquí." })}
                        >
                          términos y condiciones
                        </button>{" "}
                        y confirmo que toda la información proporcionada es correcta.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              {/* Submit Button */}
              <Button 
                type="submit" 
                disabled={registerTeam.isPending}
                className="w-full bg-gradient-to-r from-neon-pink to-neon-blue py-4 text-lg font-bold hover:shadow-2xl hover:shadow-neon-pink/50 transform hover:scale-[1.02] transition-all duration-300"
              >
                <Rocket className="mr-2 h-5 w-5" />
                {registerTeam.isPending ? "Registrando..." : "¡Inscribir Equipo!"}
              </Button>
            </form>
          </Form>

          {/* Alternative Contact */}
          <div className="mt-8 p-6 bg-background rounded-lg border border-border">
            <h3 className="text-lg font-semibold mb-3 text-center">¿Prefieres contactar directamente?</h3>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                asChild
                className="bg-neon-pink hover:shadow-lg hover:shadow-neon-pink/50 transition-all duration-300"
              >
                <a href="mailto:contacto@kinbattle2025.com">
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </a>
              </Button>
              <Button 
                asChild
                className="bg-neon-blue hover:shadow-lg hover:shadow-neon-blue/50 transition-all duration-300"
              >
                <a href="tel:+34000000000">
                  <Phone className="mr-2 h-4 w-4" />
                  Teléfono
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
