import { Trophy, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import CountdownTimer from "./countdown-timer";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-neon-pink/20 via-background to-neon-blue/20"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-neon-pink/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-blue/10 rounded-full blur-3xl animate-float" style={{animationDelay: "-3s"}}></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-6xl mx-auto">
        <h1 className="text-6xl md:text-8xl font-gaming font-black mb-6 animate-pulse-glow">
          <span className="gradient-text">KINBATTLE</span>
          <div className="text-4xl md:text-6xl mt-2">2025</div>
        </h1>
        
        <p className="text-xl md:text-3xl mb-8 text-muted-foreground font-light">
          "¡Tres equipos, un balón gigante, una batalla épica!"
        </p>

        <CountdownTimer />

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={() => scrollToSection("inscripcion")}
            className="bg-gradient-to-r from-neon-pink to-neon-blue px-8 py-4 text-lg font-bold hover:shadow-2xl hover:shadow-neon-pink/50 transform hover:scale-105 transition-all duration-300"
          >
            <Trophy className="mr-2 h-5 w-5" />
            ¡Inscríbete Ahora!
          </Button>
          <Button 
            variant="outline"
            onClick={() => scrollToSection("evento")}
            className="border-2 border-neon-pink px-8 py-4 text-lg font-bold hover:bg-neon-pink/20 transition-all duration-300"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Ver Programa
          </Button>
        </div>
      </div>
    </header>
  );
}
