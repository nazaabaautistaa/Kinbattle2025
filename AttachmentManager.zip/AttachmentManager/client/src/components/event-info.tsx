import { Calendar, Clock, MapPin, Music } from "lucide-react";

export default function EventInfo() {
  const eventDetails = [
    {
      icon: Calendar,
      title: "Fecha",
      main: "10 de junio",
      sub: "2025",
      color: "text-neon-pink",
    },
    {
      icon: Clock,
      title: "Horario",
      main: "12:40 - 13:40",
      sub: "1 hora de acción",
      color: "text-neon-blue",
    },
    {
      icon: MapPin,
      title: "Lugar",
      main: "Pabellón del IES",
      sub: '"Cañada de las Fuentes"',
      color: "text-neon-pink",
    },
    {
      icon: Music,
      title: "Extras",
      main: "DJ en vivo",
      sub: "Música épica",
      color: "text-neon-blue",
    },
  ];

  return (
    <section id="evento" className="py-20 bg-gradient-to-b from-background to-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-gaming font-bold gradient-text mb-4">
            <Calendar className="inline mr-4" />
            Información del Evento
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Prepárate para la experiencia más épica de Kin-ball del año
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {eventDetails.map((detail, index) => (
            <div 
              key={index}
              className="neon-border rounded-xl p-6 bg-card hover:neon-glow transition-all duration-300 group"
            >
              <div className="text-center">
                <div className={`text-4xl mb-4 ${detail.color} group-hover:scale-110 transition-transform duration-300`}>
                  <detail.icon className="mx-auto" />
                </div>
                <h3 className={`text-xl font-bold mb-2 ${detail.color}`}>{detail.title}</h3>
                <p className="text-2xl font-gaming font-bold">{detail.main}</p>
                <p className="text-muted-foreground">{detail.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
