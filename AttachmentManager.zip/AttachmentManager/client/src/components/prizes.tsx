import { Trophy, Award, Crown, Medal } from "lucide-react";

export default function Prizes() {
  return (
    <section id="premios" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-gaming font-bold gradient-text mb-4">
            <Trophy className="inline mr-4" />
            Premios Épicos
          </h2>
          <p className="text-xl text-muted-foreground">
            Compite por increíbles recompensas
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* First Place */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
            <div className="relative bg-card border-2 border-yellow-400 rounded-xl p-8 hover:scale-105 transition-all duration-300">
              <div className="text-center">
                <div className="text-6xl mb-4 text-yellow-400">
                  <Crown className="mx-auto" />
                </div>
                <h3 className="text-3xl font-gaming font-bold text-yellow-400 mb-4">1er LUGAR</h3>
                <div className="bg-yellow-400/10 rounded-lg p-4 mb-4">
                  <p className="text-2xl font-bold text-white">2 bolsas de chuches</p>
                  <p className="text-muted-foreground">por equipo</p>
                </div>
                <div className="text-yellow-400 text-4xl">
                  <Medal className="mx-auto" />
                </div>
              </div>
            </div>
          </div>

          {/* Second Place */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-400 to-gray-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
            <div className="relative bg-card border-2 border-gray-400 rounded-xl p-8 hover:scale-105 transition-all duration-300">
              <div className="text-center">
                <div className="text-6xl mb-4 text-gray-400">
                  <Award className="mx-auto" />
                </div>
                <h3 className="text-3xl font-gaming font-bold text-gray-400 mb-4">2º LUGAR</h3>
                <div className="bg-gray-400/10 rounded-lg p-4 mb-4">
                  <p className="text-2xl font-bold text-white">1 bolsa de chuches</p>
                  <p className="text-muted-foreground">por equipo</p>
                </div>
                <div className="text-gray-400 text-4xl">
                  <Trophy className="mx-auto" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
