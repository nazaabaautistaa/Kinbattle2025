import { Instagram, Twitter, Youtube } from "lucide-react";
import { FaTiktok } from "react-icons/fa";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="text-3xl font-gaming font-bold gradient-text mb-4">KINBATTLE 2025</div>
            <p className="text-muted-foreground mb-4 max-w-md">
              El torneo de Kin-ball más épico del año. Tres equipos, un balón gigante, una batalla legendaria.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-muted-foreground hover:text-neon-pink transition-colors duration-300"
                aria-label="Instagram"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-neon-blue transition-colors duration-300"
                aria-label="Twitter"
              >
                <Twitter className="h-6 w-6" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-neon-pink transition-colors duration-300"
                aria-label="TikTok"
              >
                <FaTiktok className="h-6 w-6" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-neon-blue transition-colors duration-300"
                aria-label="YouTube"
              >
                <Youtube className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-neon-pink">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection("evento")}
                  className="text-muted-foreground hover:text-white transition-colors duration-300"
                >
                  Información del Evento
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("premios")}
                  className="text-muted-foreground hover:text-white transition-colors duration-300"
                >
                  Premios
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("merch")}
                  className="text-muted-foreground hover:text-white transition-colors duration-300"
                >
                  Merchandise
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection("inscripcion")}
                  className="text-muted-foreground hover:text-white transition-colors duration-300"
                >
                  Inscripción
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-neon-blue">Contacto</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-center">
                <span className="mr-2">📧</span>
                contacto@kinbattle2025.com
              </li>
              <li className="flex items-center">
                <span className="mr-2">📍</span>
                IES Cañada de las Fuentes
              </li>
              <li className="flex items-center">
                <span className="mr-2">📅</span>
                10 de junio, 2025
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm mb-4 md:mb-0">
            © 2025 Kinbattle. Todos los derechos reservados.
          </p>
          <p className="text-muted-foreground text-sm">
            Web creada por estudiantes de 1º Bach – IES Cañada de las Fuentes
          </p>
        </div>
      </div>
    </footer>
  );
}
