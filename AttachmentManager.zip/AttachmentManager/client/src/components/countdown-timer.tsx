import { useCountdown } from "@/hooks/use-countdown";

export default function CountdownTimer() {
  const { days, hours, minutes, seconds } = useCountdown("2025-06-10T12:40:00");

  return (
    <div className="mb-12">
      <div className="text-sm uppercase tracking-wider text-neon-pink mb-4">Evento en:</div>
      <div className="flex justify-center space-x-4 md:space-x-8">
        <div className="text-center">
          <div className="text-3xl md:text-5xl font-bold text-white neon-border rounded-lg p-4 bg-card animate-countdown">
            {days.toString().padStart(3, '0')}
          </div>
          <div className="text-sm mt-2 text-muted-foreground">DÍAS</div>
        </div>
        <div className="text-center">
          <div className="text-3xl md:text-5xl font-bold text-white neon-border rounded-lg p-4 bg-card animate-countdown">
            {hours.toString().padStart(2, '0')}
          </div>
          <div className="text-sm mt-2 text-muted-foreground">HORAS</div>
        </div>
        <div className="text-center">
          <div className="text-3xl md:text-5xl font-bold text-white neon-border rounded-lg p-4 bg-card animate-countdown">
            {minutes.toString().padStart(2, '0')}
          </div>
          <div className="text-sm mt-2 text-muted-foreground">MIN</div>
        </div>
        <div className="text-center">
          <div className="text-3xl md:text-5xl font-bold text-white neon-border rounded-lg p-4 bg-card animate-countdown">
            {seconds.toString().padStart(2, '0')}
          </div>
          <div className="text-sm mt-2 text-muted-foreground">SEG</div>
        </div>
      </div>
    </div>
  );
}
