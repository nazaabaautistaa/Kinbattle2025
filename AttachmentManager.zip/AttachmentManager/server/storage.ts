import { teams, orders, merchandiseItems, type Team, type InsertTeam, type Order, type InsertOrder, type MerchandiseItem } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  getTeams(): Promise<Team[]>;
  getTeam(id: number): Promise<Team | undefined>;

  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;

  // Merchandise operations
  getMerchandiseItems(): Promise<MerchandiseItem[]>;
  getMerchandiseItem(id: number): Promise<MerchandiseItem | undefined>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize merchandise items on startup
    this.initializeMerchandise();
  }

  private async initializeMerchandise() {
    try {
      // Check if merchandise items already exist
      const existingItems = await db.select().from(merchandiseItems);
      if (existingItems.length > 0) {
        return; // Items already exist
      }

      // Insert initial merchandise items
      const items = [
        {
          name: "Camiseta Oficial",
          description: "Colores disponibles: Fucsia, Azul, Negro",
          price: 1500, // 15€ in cents
          colors: ["#ff00cc", "#3333ff", "#000000"],
          icon: "fas fa-tshirt",
          category: "clothing",
        },
        {
          name: "Gorra Kinbattle",
          description: "Con logo bordado",
          price: 800, // 8€ in cents
          colors: ["#ff00cc", "#3333ff"],
          icon: "fas fa-hat-cowboy",
          category: "accessories",
        },
        {
          name: "Botella Deportiva",
          description: "Reutilizable, con logo y colores del torneo",
          price: 1000, // 10€ in cents
          colors: ["#ff00cc", "#3333ff"],
          icon: "fas fa-bottle-water",
          category: "accessories",
        },
        {
          name: "Pulseras de Silicona",
          description: "¡Respeta, coopera, compite!",
          price: 300, // 3€ in cents
          colors: ["#ff00cc", "#3333ff", "#ffffff"],
          icon: "fas fa-hand",
          category: "accessories",
        },
      ];

      await db.insert(merchandiseItems).values(items);
    } catch (error) {
      console.error("Error initializing merchandise:", error);
    }
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const [team] = await db
      .insert(teams)
      .values(insertTeam)
      .returning();
    return team;
  }

  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams);
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders);
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async getMerchandiseItems(): Promise<MerchandiseItem[]> {
    return await db.select().from(merchandiseItems);
  }

  async getMerchandiseItem(id: number): Promise<MerchandiseItem | undefined> {
    const [item] = await db.select().from(merchandiseItems).where(eq(merchandiseItems.id, id));
    return item || undefined;
  }
}

export const storage = new DatabaseStorage();
